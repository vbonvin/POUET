INSTALLATION
============

The following python packages must be installed:
- matplotlib, numpy, scipy
- astropy
- urllib2 (should be a standard package)
- PyQt4

EXECUTION
=========
$ python gui_sky_monitoring
Click start/refresh to analyse the current image from the Danish All Sky (http://allsky-dk154.asu.cas.cz/) located in la Silla.
The analysis is done every 2 minutes (same frequency as the all sky actualisation)

PRINCIPLE
=========
There is a peak detection. The algorithm selects only well behaved peaks (i.e. round enough and with a small enough FHWM), thus some peaks in the border of the image may be missed.

There is also an alert if the wind is too high as defined by the parameters in util.py.

AUTHORS
=======
Question, beers and suggestions must directed at:
* thibault.kuntzer@epfl.ch
* vivien.bonvin@epfl.ch
