INSTALLATION
============

The following python packages must be installed:
- matplotlib, numpy
- ephem (To compute the ephemerids in python)
- urllib2 (should be a standard package)
- PyQt4

EXECUTION
=========
$ python gui_visible_sky
Enter your preference in the options and click plot

WARNING: You must enter the __correct UTC date__, *not* the night date.

PRINCIPLE
=========
Just a simple look up for a sufficiently low airmass and high Moon separation angle.

There is also an alert if the wind is too high as defined by the parameters in util.py.

AUTHORS
=======
Questions, beers and suggestions must directed at:
* thibault.kuntzer@epfl.ch
* vivien.bonvin@epfl.ch
